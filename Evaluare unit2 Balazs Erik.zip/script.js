// Selectăm elementele
const monitoringSection = document.querySelector("#resource-monitoring");
const slideshow = document.querySelector(".slideshow");
const images = document.querySelectorAll(".monitoring-image");
let slides = document.querySelectorAll(".slide");
let currentSlide = 0;

// Funcția pentru schimbarea slide-urilor
function showNextSlide() {
    // Ascundem slide-ul curent
    slides[currentSlide].classList.remove("active");
    // Calculăm următorul slide
    currentSlide = (currentSlide + 1) % slides.length;
    // Afișăm următorul slide
    slides[currentSlide].classList.add("active");
}

// Setăm intervalul de 3 secunde
let slideshowInterval = null;

// La dublu-click pe secțiunea de monitorizare resurse
monitoringSection.addEventListener("dblclick", () => {
    // Ascundem imaginile statice
    document.querySelector(".monitoring-images").style.display = "none";
    
    // Arătăm slideshow-ul
    slideshow.style.display = "block";

    // Începem slideshow-ul
    slideshowInterval = setInterval(showNextSlide, 3000);
});

// Adăugăm butoane de control pentru a naviga între slide-uri
document.querySelector(".prev").addEventListener("click", () => {
    // Ascundem slide-ul curent
    slides[currentSlide].classList.remove("active");
    // Calculăm slide-ul anterior
    currentSlide = (currentSlide - 1 + slides.length) % slides.length;
    // Afișăm slide-ul anterior
    slides[currentSlide].classList.add("active");
});

document.querySelector(".next").addEventListener("click", showNextSlide);
